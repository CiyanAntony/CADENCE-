# GitHub security cleanup report

This archive was prepared for source control.

Changes made:
- Removed generated Vercel build output (`.vercel/`), which duplicates compiled app assets and can embed runtime configuration.
- Removed workspace-specific `.grok/` metadata and bundled skill/reference material.
- Removed generated `artifacts/` and `.node_modules.lock`.
- Removed the hard-coded preview OAuth client secret from `src/lib/auth/preview.ts`.
- Added `.gitignore` rules for environment files, credentials, dependencies, and build output.
- Added `.env.example` containing variable names only; it has no real credentials.

Important:
- `src/lib/auth/preview.ts` now has an empty preview client secret. Federated preview sign-in may not work unless `GROK_AUTH_CLIENT_SECRET` or `GROK_PREVIEW_CLIENT_SECRET` is provided securely through environment configuration.
- This is a best-effort automated scan, not a guarantee that every secret or sensitive item has been found. Review before publishing.
- If the removed secret was ever used outside this private workspace, rotate/revoke it at its issuer. Removing it from this ZIP does not remove it from the original file or any previous Git history.

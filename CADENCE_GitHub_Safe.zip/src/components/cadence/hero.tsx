import { useEffect, useRef } from "react";
import { engine } from "@/lib/music/engine";
import { useCadence } from "@/lib/music/store";
import { keyById, resolveSlot, scaleById } from "@/lib/music/theory";

export function Hero() {
  const slots = useCadence((state) => state.slots);
  const keyId = useCadence((state) => state.keyId);
  const scaleId = useCadence((state) => state.scaleId);
  const register = useCadence((state) => state.register);
  const cueIndex = useCadence((state) => state.cueIndex);
  const playhead = useCadence((state) => state.playhead);
  const isolate = useCadence((state) => state.isolate);
  const barRef = useRef<HTMLSpanElement>(null);

  const index = playhead.playing ? playhead.chordIndex : cueIndex;
  const safeIndex = Math.min(Math.max(0, index), Math.max(0, slots.length - 1));
  const slot = slots[safeIndex];
  const chord = slot ? resolveSlot(slot, keyId, scaleId, register) : null;
  const nextSlot = slots[(safeIndex + 1) % slots.length];
  const next = nextSlot && slots.length > 1 ? resolveSlot(nextSlot, keyId, scaleId, register) : null;
  const key = keyById(keyId);
  const scale = scaleById(scaleId);
  const label = playhead.counting ? String(playhead.countBeat) : (chord?.symbol ?? "—");

  useEffect(() => {
    return engine.subscribe((visual) => {
      const bar = barRef.current;
      if (!bar) return;
      const amount = visual.playing && !visual.counting ? visual.fraction : 0;
      bar.style.transform = `scaleX(${Math.max(0, Math.min(1, amount))})`;
    });
  }, []);

  return (
    <section className="relative overflow-hidden rounded-2xl border border-line bg-surface px-5 py-5 sm:px-7 sm:py-6">
      <p className="text-sm font-medium tracking-wide text-amber">
        {playhead.counting ? "Count-in" : (chord?.roman ?? "")}
        {!playhead.counting && chord ? <span className="text-muted"> · {chord.role}</span> : null}
      </p>
      <p key={label} data-testid="hero-symbol" className="hero-symbol chord-in mt-2 text-fg">
        {label}
      </p>
      <p className="mt-3 text-sm text-muted">
        {key.label} {scale.name}
        {isolate ? " · looping this chord" : ""}
        {!playhead.playing && !playhead.counting ? " · cued" : ""}
      </p>
      <div className="mt-6 flex items-end justify-between gap-4">
        <div className="flex min-w-0 flex-1 gap-1.5" aria-hidden>
          {slot
            ? Array.from({ length: slot.beats }, (_, beat) => (
                <span
                  key={beat}
                  className={
                    playhead.playing && !playhead.counting && beat <= playhead.beat
                      ? "h-1.5 flex-1 rounded-full bg-amber"
                      : "h-1.5 flex-1 rounded-full bg-line"
                  }
                />
              ))
            : null}
        </div>
        <p className="shrink-0 text-right text-sm text-faint">
          {isolate ? "Again" : next ? `Next ${next.symbol}` : ""}
        </p>
      </div>
      <span ref={barRef} className="absolute inset-x-0 bottom-0 h-1 origin-left bg-amber" style={{ transform: "scaleX(0)" }} />
    </section>
  );
}

import { useState } from "react";
import { engine } from "@/lib/music/engine";
import { useCadence } from "@/lib/music/store";
import { Section } from "@/components/cadence/ui";
import { keyById, scaleById } from "@/lib/music/theory";

export function Sketches() {
  const sketchName = useCadence((state) => state.sketchName);
  const setSketchName = useCadence((state) => state.setSketchName);
  const library = useCadence((state) => state.library);
  const activeSketchId = useCadence((state) => state.activeSketchId);
  const saveSketch = useCadence((state) => state.saveSketch);
  const loadSketch = useCadence((state) => state.loadSketch);
  const deleteSketch = useCadence((state) => state.deleteSketch);
  const newSketch = useCadence((state) => state.newSketch);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  return (
    <Section title="Sketches" hint="Kept on this device">
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          saveSketch();
        }}
      >
        <input
          value={sketchName}
          onChange={(event) => setSketchName(event.target.value)}
          aria-label="Sketch name"
          maxLength={48}
          className="min-h-11 flex-1 rounded-lg border border-line bg-inset px-3 text-sm text-fg"
        />
        <button type="submit" className="min-h-11 rounded-lg bg-amber px-4 text-sm font-medium text-amber-ink">
          {activeSketchId ? "Update sketch" : "Save sketch"}
        </button>
        <button
          type="button"
          onClick={() => {
            engine.stop();
            newSketch();
          }}
          className="min-h-11 rounded-lg border border-line bg-raised px-4 text-sm font-medium"
        >
          New
        </button>
      </form>
      {library.length === 0 ? (
        <p className="mt-3 text-sm text-muted">The desk restores itself. Save a sketch when you want more than one.</p>
      ) : (
        <ul className="mt-3 max-h-64 space-y-2 overflow-auto">
          {library.map((sketch) => {
            const key = keyById(sketch.keyId);
            const scale = scaleById(sketch.scaleId);
            const confirming = pendingDelete === sketch.id;
            return (
              <li key={sketch.id} className="flex items-center gap-2 rounded-lg border border-line bg-raised px-3 py-2">
                <button
                  type="button"
                  onClick={() => {
                    engine.stop();
                    loadSketch(sketch.id);
                  }}
                  className="min-h-11 flex-1 text-left"
                >
                  <span className="block text-sm font-medium">{sketch.name}</span>
                  <span className="block text-xs text-faint">
                    {key.label} {scale.name} · {sketch.slots.length} chords
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!confirming) {
                      setPendingDelete(sketch.id);
                      return;
                    }
                    deleteSketch(sketch.id);
                    setPendingDelete(null);
                  }}
                  className="min-h-11 shrink-0 px-2 text-sm text-muted"
                >
                  {confirming ? "Confirm" : "Remove"}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </Section>
  );
}

import { useEffect, useState } from "react";
import { Guitar, Piano } from "lucide-react";
import { Section } from "@/components/cadence/ui";
import { cn } from "@/lib/cn";
import { engine } from "@/lib/music/engine";
import { PATTERNS, type Pattern } from "@/lib/music/patterns";
import { useCadence, type Timbre } from "@/lib/music/store";
import type { Register } from "@/lib/music/theory";

const REGISTERS: { id: Register; label: string }[] = [
  { id: "low", label: "Low" },
  { id: "mid", label: "Mid" },
  { id: "high", label: "High" },
];

export function PatternBoard() {
  const patternId = useCadence((state) => state.patternId);
  const setPattern = useCadence((state) => state.setPattern);
  const timbre = useCadence((state) => state.timbre);
  const setTimbre = useCadence((state) => state.setTimbre);
  const register = useCadence((state) => state.register);
  const setRegister = useCadence((state) => state.setRegister);
  const setAllBeats = useCadence((state) => state.setAllBeats);
  const playing = useCadence((state) => state.playhead.playing);
  const [cellStep, setCellStep] = useState(-1);

  useEffect(() => {
    return engine.subscribe((visual) => {
      const step = visual.playing && !visual.counting ? visual.cellStep : -1;
      setCellStep((current) => (current === step ? current : step));
    });
  }, []);

  return (
    <Section title="Pattern" hint="Strum or arpeggio">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg border border-line p-1">
          <SoundButton current={timbre} id="guitar" label="Guitar" onClick={setTimbre}>
            <Guitar className="size-4" />
            Guitar
          </SoundButton>
          <SoundButton current={timbre} id="keys" label="Keys" onClick={setTimbre}>
            <Piano className="size-4" />
            Keys
          </SoundButton>
        </div>
        <div className="flex rounded-lg border border-line p-1">
          {REGISTERS.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={register === item.id}
              onClick={() => setRegister(item.id)}
              className={cn(
                "min-h-11 rounded-md px-3 text-sm font-medium",
                register === item.id ? "bg-amber text-amber-ink" : "text-muted hover:text-fg",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {PATTERNS.map((pattern) => {
          const active = pattern.id === patternId;
          return (
            <button
              key={pattern.id}
              type="button"
              aria-pressed={active}
              onClick={() => setPattern(pattern.id)}
              className={cn(
                "rounded-xl border px-3 py-3 text-left",
                active ? "border-amber bg-amber-dim" : "border-line bg-raised hover:border-muted",
              )}
            >
              <span className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium">{pattern.name}</span>
                <span className="text-xs tracking-wide text-faint uppercase">{pattern.group}</span>
              </span>
              <PatternGlyph pattern={pattern} step={active && playing ? cellStep : -1} />
              <span className="mt-2 block text-xs text-muted">{pattern.blurb}</span>
            </button>
          );
        })}
      </div>
      {patternId === "waltz" ? (
        <button
          type="button"
          onClick={() => setAllBeats(3)}
          className="mt-3 min-h-11 text-sm text-amber underline-offset-2 hover:underline"
        >
          Set every chord to 3 beats
        </button>
      ) : null}
    </Section>
  );
}

function SoundButton({
  current,
  id,
  label,
  onClick,
  children,
}: {
  current: Timbre;
  id: Timbre;
  label: string;
  onClick: (timbre: Timbre) => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={current === id}
      aria-label={label}
      onClick={() => onClick(id)}
      className={cn(
        "flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-medium",
        current === id ? "bg-amber text-amber-ink" : "text-muted hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

function PatternGlyph({ pattern, step }: { pattern: Pattern; step: number }) {
  const total = pattern.cellBeats * 4;
  return (
    <span className="mt-3 flex h-6 items-end gap-px" aria-hidden>
      {Array.from({ length: total }, (_, index) => {
        const event = pattern.events.find((item) => item.step === index);
        const beat = index % 4 === 0;
        const lit = step === index;
        const up = event?.gesture === "up";
        return (
          <span key={index} className={cn("flex h-6 w-1.5 flex-col", beat && index > 0 ? "ml-1" : "", up ? "justify-start" : "justify-end")}>
            <span
              className={cn(
                "w-full rounded-full",
                event ? "h-3" : "h-1",
                lit ? "bg-fg" : event ? "bg-amber" : "bg-line",
              )}
            />
          </span>
        );
      })}
    </span>
  );
}

import { useRef } from "react";
import { AudioLines, Minus, Pause, Play, Plus, Repeat, Square } from "lucide-react";
import { cn } from "@/lib/cn";
import { engine } from "@/lib/music/engine";
import { useCadence } from "@/lib/music/store";

export function Transport() {
  const playing = useCadence((state) => state.playhead.playing);
  const tempo = useCadence((state) => state.tempo);
  const swing = useCadence((state) => state.swing);
  const volume = useCadence((state) => state.volume);
  const loop = useCadence((state) => state.loop);
  const metronome = useCadence((state) => state.metronome);
  const countIn = useCadence((state) => state.countIn);
  const setTempo = useCadence((state) => state.setTempo);
  const setSwing = useCadence((state) => state.setSwing);
  const setVolume = useCadence((state) => state.setVolume);
  const setLoop = useCadence((state) => state.setLoop);
  const setMetronome = useCadence((state) => state.setMetronome);
  const setCountIn = useCadence((state) => state.setCountIn);
  const taps = useRef<number[]>([]);

  function tap() {
    const now = performance.now();
    const recent = taps.current.filter((time) => now - time < 2200);
    recent.push(now);
    taps.current = recent.slice(-6);
    if (recent.length < 2) return;
    let total = 0;
    for (let i = 1; i < recent.length; i++) total += recent[i] - recent[i - 1];
    setTempo(Math.round(60000 / (total / (recent.length - 1))));
  }

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 px-3 pb-3">
      <div className="float-bar pointer-events-auto mx-auto flex max-w-4xl flex-col gap-3 rounded-2xl border border-line bg-surface px-3 py-3 lg:flex-row lg:items-center lg:px-4">
        <div className="flex items-center gap-2">
          <IconToggle label="Stop" onClick={() => engine.stop()}>
            <Square className="size-4 fill-current" />
          </IconToggle>
          <button
            type="button"
            data-testid="play"
            aria-label={playing ? "Pause" : "Play"}
            onClick={() => engine.toggle()}
            className="flex size-14 items-center justify-center rounded-full bg-amber text-amber-ink"
          >
            {playing ? <Pause className="size-6" /> : <Play className="ml-0.5 size-6 fill-current" />}
          </button>
          <IconToggle label="Loop progression" pressed={loop} onClick={() => setLoop(!loop)}>
            <Repeat className="size-4" />
          </IconToggle>
          <IconToggle label="Metronome" pressed={metronome} onClick={() => setMetronome(!metronome)}>
            <AudioLines className="size-4" />
          </IconToggle>
          <IconToggle label="Count in" pressed={countIn} onClick={() => setCountIn(!countIn)}>
            <span className="text-xs font-semibold tracking-wide">1</span>
          </IconToggle>
        </div>
        <div className="grid flex-1 grid-cols-2 gap-x-3 gap-y-2 lg:grid-cols-[1.5fr_1fr_0.8fr] lg:items-center">
          <div className="col-span-2 flex items-center gap-2 lg:col-span-1">
            <IconToggle label="Slower" onClick={() => setTempo(tempo - 1)}>
              <Minus className="size-4" />
            </IconToggle>
            <label className="flex min-w-0 flex-1 flex-col gap-1 text-xs text-muted">
              <span className="flex justify-between tabular-nums">
                <span>Tempo</span>
                <span className="text-fg">{tempo} bpm</span>
              </span>
              <input
                type="range"
                min={40}
                max={200}
                value={tempo}
                aria-label="Tempo"
                onChange={(event) => setTempo(Number(event.target.value))}
              />
            </label>
            <IconToggle label="Faster" onClick={() => setTempo(tempo + 1)}>
              <Plus className="size-4" />
            </IconToggle>
            <button
              type="button"
              onClick={tap}
              className="min-h-11 rounded-lg border border-line bg-raised px-3 text-sm font-medium"
            >
              Tap
            </button>
          </div>
          <label className="flex flex-col gap-1 text-xs text-muted">
            <span className="flex justify-between">
              <span>Swing</span>
              <span className="tabular-nums text-fg">{swing === 0 ? "Straight" : swing}</span>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={swing}
              aria-label="Swing"
              onChange={(event) => setSwing(Number(event.target.value))}
            />
          </label>
          <label className="flex flex-col gap-1 text-xs text-muted">
            <span className="flex justify-between">
              <span>Volume</span>
              <span className="tabular-nums text-fg">{volume}</span>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={volume}
              aria-label="Volume"
              onChange={(event) => setVolume(Number(event.target.value))}
            />
          </label>
        </div>
      </div>
    </div>
  );
}

function IconToggle({
  children,
  label,
  onClick,
  pressed,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "flex size-11 items-center justify-center rounded-lg border",
        pressed ? "border-amber bg-amber text-amber-ink" : "border-line bg-raised text-fg",
      )}
    >
      {children}
    </button>
  );
}

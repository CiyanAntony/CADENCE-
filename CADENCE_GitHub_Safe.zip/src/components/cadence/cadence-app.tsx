import { useEffect, useState } from "react";
import { Check, Copy } from "lucide-react";
import { ChordEditor } from "@/components/cadence/chord-editor";
import { HarmonyPanel } from "@/components/cadence/harmony-panel";
import { Hero } from "@/components/cadence/hero";
import { PatternBoard } from "@/components/cadence/pattern-board";
import { Presets } from "@/components/cadence/presets";
import { ProgressionStrip } from "@/components/cadence/progression-strip";
import { Sketches } from "@/components/cadence/sketches";
import { Transport } from "@/components/cadence/transport";
import { engine } from "@/lib/music/engine";
import { getPattern } from "@/lib/music/patterns";
import { useCadence } from "@/lib/music/store";
import { formatProgression, keyById, scaleById } from "@/lib/music/theory";

export function CadenceApp() {
  const playing = useCadence((state) => state.playhead.playing);
  const sketchName = useCadence((state) => state.sketchName);
  const setSketchName = useCadence((state) => state.setSketchName);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    void useCadence.persist.rehydrate();
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
      if (event.code === "Space" && !typing) {
        event.preventDefault();
        engine.toggle();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      engine.stop();
    };
  }, []);

  async function copyProgression() {
    const state = useCadence.getState();
    const text = formatProgression(state.slots, state.keyId, state.scaleId);
    const key = keyById(state.keyId);
    const scale = scaleById(state.scaleId);
    const pattern = getPattern(state.patternId);
    const payload = `${text.symbols}\n${text.romans}\n${key.label} ${scale.name} · ${state.tempo} bpm · ${pattern.name}`;
    try {
      await navigator.clipboard.writeText(payload);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="min-h-dvh bg-bg text-fg" data-playing={playing ? "true" : "false"}>
      <div className="h-1 bg-amber" />
      <div className="mx-auto flex w-full max-w-4xl flex-col gap-4 px-4 pt-5 pb-64 lg:pb-32">
        <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <svg viewBox="0 0 28 28" className="size-9 shrink-0" aria-hidden>
              <rect width="28" height="28" rx="8" className="fill-amber" />
              <rect x="7" y="14" width="3" height="7" rx="1" className="fill-amber-ink" />
              <rect x="12.5" y="9" width="3" height="12" rx="1" className="fill-amber-ink" />
              <rect x="18" y="6" width="3" height="15" rx="1" className="fill-amber-ink" />
            </svg>
            <div>
              <h1 className="font-display text-2xl leading-none tracking-tight">Cadence</h1>
              <p className="mt-1 text-sm text-muted">Progressions for writing songs</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input
              value={sketchName}
              onChange={(event) => setSketchName(event.target.value)}
              aria-label="Sketch name"
              maxLength={48}
              className="min-h-11 w-full rounded-lg border border-line bg-surface px-3 text-sm sm:w-56"
            />
            <button
              type="button"
              onClick={() => void copyProgression()}
              className="flex min-h-11 items-center gap-2 rounded-lg border border-line bg-surface px-3 text-sm font-medium"
            >
              {copied ? <Check className="size-4 text-amber" /> : <Copy className="size-4" />}
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
        </header>

        <Hero />
        <ProgressionStrip />
        <ChordEditor />
        <HarmonyPanel />
        <PatternBoard />
        <Presets />
        <Sketches />
      </div>
      <Transport />
    </div>
  );
}

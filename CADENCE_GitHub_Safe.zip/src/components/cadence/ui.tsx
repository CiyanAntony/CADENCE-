import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Section({
  title,
  hint,
  children,
  action,
}: {
  title: string;
  hint?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="rounded-xl border border-line bg-surface p-4">
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h2 className="text-xs font-medium tracking-widest text-muted uppercase">{title}</h2>
        {action ?? (hint ? <p className="text-right text-xs text-faint">{hint}</p> : null)}
      </header>
      {children}
    </section>
  );
}

export function Chip({
  active,
  children,
  onClick,
  disabled,
  label,
  className,
}: {
  active?: boolean;
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  label?: string;
  className?: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "min-h-11 rounded-lg border px-3 text-sm font-medium transition-colors duration-200",
        "disabled:cursor-not-allowed disabled:opacity-40",
        active
          ? "border-amber bg-amber text-amber-ink"
          : "border-line bg-raised text-fg hover:border-muted",
        className,
      )}
    >
      {children}
    </button>
  );
}

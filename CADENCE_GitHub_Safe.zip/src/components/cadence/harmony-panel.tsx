import { Section } from "@/components/cadence/ui";
import { cn } from "@/lib/cn";
import { useCadence } from "@/lib/music/store";
import { KEYS, SCALES, createSlot, resolveSlot, scaleNotes } from "@/lib/music/theory";

export function HarmonyPanel() {
  const keyId = useCadence((state) => state.keyId);
  const scaleId = useCadence((state) => state.scaleId);
  const register = useCadence((state) => state.register);
  const setKey = useCadence((state) => state.setKey);
  const setScale = useCadence((state) => state.setScale);
  const addChord = useCadence((state) => state.addChord);
  const slots = useCadence((state) => state.slots);
  const notes = scaleNotes(keyId, scaleId);
  const locked = slots.filter((slot) => slot.lockQuality).length;

  return (
    <Section title="Key" hint={locked > 0 ? `${locked} locked` : "All follow the scale"}>
      <div className="grid grid-cols-6 gap-1.5 sm:grid-cols-12">
        {KEYS.map((key) => (
          <button
            key={key.id}
            type="button"
            aria-pressed={key.id === keyId}
            onClick={() => setKey(key.id)}
            className={cn(
              "min-h-11 rounded-lg border text-sm font-medium",
              key.id === keyId
                ? "border-amber bg-amber text-amber-ink"
                : "border-line bg-raised text-fg hover:border-muted",
            )}
          >
            {key.label}
          </button>
        ))}
      </div>
      <p className="mt-3 text-sm text-muted tabular-nums">{notes.map((note) => note.name).join("  ")}</p>
      <p className="mt-4 mb-2 text-xs tracking-widest text-faint uppercase">Scale</p>
      <div className="flex flex-wrap gap-1.5">
        {SCALES.map((scale) => (
          <button
            key={scale.id}
            type="button"
            aria-pressed={scale.id === scaleId}
            title={scale.hint}
            onClick={() => setScale(scale.id)}
            className={cn(
              "min-h-11 rounded-lg border px-3 text-sm font-medium",
              scale.id === scaleId
                ? "border-amber bg-amber text-amber-ink"
                : "border-line bg-raised text-fg hover:border-muted",
            )}
          >
            {scale.name}
          </button>
        ))}
      </div>
      <p className="mt-2 text-xs text-faint">Key transposes the whole loop. Scale recolors unlocked chords.</p>
      <p className="mt-4 mb-2 text-xs tracking-widest text-faint uppercase">Add to the end</p>
      <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
        {([1, 2, 3, 4, 5, 6, 7] as const).map((degree) => {
          const preview = resolveSlot(createSlot({ id: `add-${degree}`, degree }), keyId, scaleId, register);
          return (
            <button
              key={degree}
              type="button"
              onClick={() => addChord(degree, "end")}
              className="min-h-11 rounded-lg border border-line bg-raised px-1 text-sm font-medium text-fg hover:border-muted"
            >
              <span className="block text-xs text-amber">{preview.roman}</span>
              {preview.symbol}
            </button>
          );
        })}
      </div>
    </Section>
  );
}

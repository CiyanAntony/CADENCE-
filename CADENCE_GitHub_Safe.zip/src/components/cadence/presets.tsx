import { engine } from "@/lib/music/engine";
import { PRESETS } from "@/lib/music/presets";
import { useCadence } from "@/lib/music/store";
import { Section } from "@/components/cadence/ui";
import { cn } from "@/lib/cn";

export function Presets() {
  const applyPreset = useCadence((state) => state.applyPreset);

  return (
    <Section title="Presets" hint="Keeps your key">
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {PRESETS.map((preset) => (
          <button
            key={preset.id}
            type="button"
            data-testid="preset"
            onClick={() => {
              engine.stop();
              applyPreset(preset.id);
            }}
            className={cn(
              "min-h-11 rounded-xl border border-line bg-raised px-3 py-2.5 text-left",
              "hover:border-muted",
            )}
          >
            <span className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-medium">{preset.name}</span>
              <span className="text-xs tracking-wide text-faint uppercase">{preset.tag}</span>
            </span>
            <span className="mt-1 block text-xs text-muted">{preset.numerals}</span>
          </button>
        ))}
      </div>
    </Section>
  );
}

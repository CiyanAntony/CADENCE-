import { useEffect, useRef } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/cn";
import { engine } from "@/lib/music/engine";
import { useCadence } from "@/lib/music/store";
import { formatProgression, resolveSlot } from "@/lib/music/theory";

export function ProgressionStrip() {
  const slots = useCadence((state) => state.slots);
  const selectedId = useCadence((state) => state.selectedId);
  const cueIndex = useCadence((state) => state.cueIndex);
  const playhead = useCadence((state) => state.playhead);
  const keyId = useCadence((state) => state.keyId);
  const scaleId = useCadence((state) => state.scaleId);
  const register = useCadence((state) => state.register);
  const select = useCadence((state) => state.select);
  const setCue = useCadence((state) => state.setCue);
  const addChord = useCadence((state) => state.addChord);
  const bars = useRef(new Map<number, HTMLElement>());
  const notation = formatProgression(slots, keyId, scaleId);
  const beats = slots.reduce((sum, slot) => sum + slot.beats, 0);

  useEffect(() => {
    return engine.subscribe((visual) => {
      bars.current.forEach((element, index) => {
        const on = visual.playing && !visual.counting && visual.chordIndex === index;
        element.style.transform = `scaleX(${on ? Math.max(0, Math.min(1, visual.fraction)) : 0})`;
      });
    });
  }, []);

  return (
    <div className="rounded-xl border border-line bg-inset p-3">
      <div className="mb-3 flex items-baseline justify-between gap-3 px-1">
        <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Progression</h2>
        <p className="text-xs text-faint tabular-nums">
          {beats} beats{beats % 4 === 0 ? ` · ${beats / 4} ${beats === 4 ? "bar" : "bars"}` : ""}
        </p>
      </div>
      <div className="flex gap-2 overflow-x-auto overscroll-x-contain px-1 py-1" role="list" aria-label="Progression">
        {slots.map((slot, index) => {
          const chord = resolveSlot(slot, keyId, scaleId, register);
          const selected = slot.id === selectedId;
          const active = playhead.playing && !playhead.counting && playhead.chordIndex === index;
          const pending = playhead.counting && cueIndex === index;
          const cued = !playhead.playing && cueIndex === index;
          return (
            <div
              key={slot.id}
              role="listitem"
              className={cn(
                "relative w-max min-w-32 max-w-48 shrink-0 rounded-xl border",
                active ? "border-amber bg-amber text-amber-ink" : "border-line bg-surface text-fg",
                (selected && !active) || cued || pending ? "border-amber" : "",
                selected ? "ring-2 ring-amber ring-offset-2 ring-offset-inset" : "",
              )}
            >
              <button
                type="button"
                data-testid="chord-card"
                data-symbol={chord.symbol}
                aria-current={active ? "true" : undefined}
                aria-pressed={selected}
                onClick={() => {
                  select(slot.id);
                  if (!useCadence.getState().playhead.playing) setCue(index);
                }}
                className="flex w-full flex-col items-start px-3 py-3 text-left"
              >
                <span className={cn("text-xs font-medium", active ? "text-amber-ink" : "text-amber")}>{chord.roman}</span>
                <span className="mt-2 font-display text-2xl leading-none tracking-tight">{chord.symbol}</span>
                <span className="mt-3 flex w-full gap-1" aria-hidden>
                  {Array.from({ length: slot.beats }, (_, beat) => (
                    <span
                      key={beat}
                      className={cn(
                        "h-1 flex-1 rounded-full",
                        active
                          ? beat <= playhead.beat
                            ? "bg-amber-ink"
                            : "bg-amber-ink/30"
                          : "bg-line",
                      )}
                    />
                  ))}
                </span>
              </button>
              {slot.lockQuality ? (
                <span
                  title="Quality is locked"
                  className={cn("absolute top-3 right-3 size-1.5 rounded-full", active ? "bg-amber-ink" : "bg-amber")}
                />
              ) : null}
              <span
                ref={(node) => {
                  if (node) bars.current.set(index, node);
                  else bars.current.delete(index);
                }}
                className={cn("absolute inset-x-0 bottom-0 h-0.5 origin-left", active ? "bg-amber-ink" : "bg-amber")}
                style={{ transform: "scaleX(0)" }}
              />
            </div>
          );
        })}
        <button
          type="button"
          onClick={() => addChord(1, "end")}
          className="flex min-h-28 w-16 shrink-0 flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-line text-muted hover:border-muted hover:text-fg"
          aria-label="Add chord"
        >
          <Plus className="size-5" />
        </button>
      </div>
      <p className="mt-3 px-1 text-sm text-fg">{notation.symbols}</p>
      <p className="px-1 text-xs text-faint">{notation.romans}</p>
    </div>
  );
}

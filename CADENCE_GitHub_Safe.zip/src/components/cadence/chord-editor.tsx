import { ChevronLeft, ChevronRight, Copy, Trash2 } from "lucide-react";
import { Chip, Section } from "@/components/cadence/ui";
import { clearLock, followQuality, useCadence } from "@/lib/music/store";
import {
  LEADS_TO,
  QUALITY_GROUPS,
  QUALITY_LABEL,
  createSlot,
  resolveSlot,
  type Accidental,
  type QualityId,
} from "@/lib/music/theory";

const BEATS = [1, 2, 3, 4, 6, 8];
const ACCIDENTALS: { id: Accidental; label: string }[] = [
  { id: -1, label: "♭" },
  { id: 0, label: "♮" },
  { id: 1, label: "♯" },
];

export function ChordEditor() {
  const slots = useCadence((state) => state.slots);
  const selectedId = useCadence((state) => state.selectedId);
  const keyId = useCadence((state) => state.keyId);
  const scaleId = useCadence((state) => state.scaleId);
  const register = useCadence((state) => state.register);
  const isolate = useCadence((state) => state.isolate);
  const updateSlot = useCadence((state) => state.updateSlot);
  const addChord = useCadence((state) => state.addChord);
  const remove = useCadence((state) => state.remove);
  const move = useCadence((state) => state.move);
  const duplicate = useCadence((state) => state.duplicate);
  const setIsolate = useCadence((state) => state.setIsolate);

  const index = slots.findIndex((slot) => slot.id === selectedId);
  const slot = index >= 0 ? slots[index] : slots[0];
  if (!slot) return null;
  const chord = resolveSlot(slot, keyId, scaleId, register);
  const suggestions = LEADS_TO[slot.degree] ?? [];

  function setAccidental(accidental: Accidental) {
    const current = resolveSlot(slot, keyId, scaleId, register);
    updateSlot(slot.id, {
      accidental,
      lockQuality: accidental === 0 ? slot.lockQuality : true,
      quality: accidental === 0 ? slot.quality : current.quality,
    });
  }

  return (
    <Section title="Edit" hint={`${index + 1} of ${slots.length}`}>
      <p className="font-display text-3xl leading-none tracking-tight">
        {chord.symbol}
        <span className="ml-3 text-base text-amber">{chord.roman}</span>
      </p>
      <p className="mt-1 text-sm text-muted">{chord.role}. Tap a degree or rewrite the color.</p>

      <div className="mt-4">
        <p className="mb-2 text-xs tracking-widest text-faint uppercase">Degree</p>
        <div className="grid grid-cols-7 gap-1">
          {([1, 2, 3, 4, 5, 6, 7] as const).map((degree) => {
            const preview = resolveSlot(createSlot({ id: `p${degree}`, degree }), keyId, scaleId, register);
            return (
              <Chip
                key={degree}
                active={slot.degree === degree}
                className="w-full px-1"
                onClick={() => updateSlot(slot.id, { degree })}
              >
                {preview.roman}
              </Chip>
            );
          })}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {ACCIDENTALS.map((item) => (
          <Chip key={item.id} active={slot.accidental === item.id} onClick={() => setAccidental(item.id)} label={item.label}>
            {item.label}
          </Chip>
        ))}
        <Chip active={slot.inversion === 0} onClick={() => updateSlot(slot.id, { inversion: 0 })}>
          Root
        </Chip>
        <Chip active={slot.inversion === 1} onClick={() => updateSlot(slot.id, { inversion: 1 })}>
          1st
        </Chip>
        <Chip active={slot.inversion === 2} onClick={() => updateSlot(slot.id, { inversion: 2 })}>
          2nd
        </Chip>
      </div>

      <div className="mt-4 space-y-3">
        {QUALITY_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="mb-2 text-xs tracking-widest text-faint uppercase">{group.label}</p>
            <div className="flex flex-wrap gap-1.5">
              {group.ids.map((quality) => (
                <Chip
                  key={quality}
                  active={chord.quality === quality && (slot.lockQuality || quality === chord.quality)}
                  onClick={() => updateSlot(slot.id, followQuality(slot, quality as QualityId))}
                >
                  {QUALITY_LABEL[quality]}
                </Chip>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3">
        {slot.lockQuality || slot.accidental !== 0 ? (
          <button
            type="button"
            onClick={() => updateSlot(slot.id, clearLock(slot))}
            className="min-h-11 text-sm text-amber underline-offset-2 hover:underline"
          >
            Follow the scale again
          </button>
        ) : (
          <p className="text-xs text-faint">Following the scale. Picking a quality locks it so the key can still transpose it.</p>
        )}
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs tracking-widest text-faint uppercase">Length</p>
        <div className="flex flex-wrap gap-1.5">
          {BEATS.map((beats) => (
            <Chip key={beats} active={slot.beats === beats} onClick={() => updateSlot(slot.id, { beats })}>
              {beats}
            </Chip>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs tracking-widest text-faint uppercase">Often next</p>
        <div className="flex flex-wrap gap-1.5">
          {suggestions.map((degree) => {
            const preview = resolveSlot(createSlot({ id: `n${degree}`, degree }), keyId, scaleId, register);
            return (
              <Chip key={degree} onClick={() => addChord(degree, "after")}>
                {preview.symbol}
              </Chip>
            );
          })}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <IconButton label="Move earlier" disabled={index <= 0} onClick={() => move(slot.id, -1)}>
          <ChevronLeft className="size-4" />
        </IconButton>
        <IconButton label="Move later" disabled={index < 0 || index >= slots.length - 1} onClick={() => move(slot.id, 1)}>
          <ChevronRight className="size-4" />
        </IconButton>
        <IconButton label="Duplicate chord" onClick={() => duplicate(slot.id)}>
          <Copy className="size-4" />
        </IconButton>
        <IconButton label="Remove chord" disabled={slots.length <= 1} onClick={() => remove(slot.id)}>
          <Trash2 className="size-4" />
        </IconButton>
        <Chip active={isolate} onClick={() => setIsolate(!isolate)}>
          Loop this chord
        </Chip>
      </div>
    </Section>
  );
}

function IconButton({
  children,
  label,
  onClick,
  disabled,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className="flex size-11 items-center justify-center rounded-lg border border-line bg-raised text-fg disabled:opacity-40"
    >
      {children}
    </button>
  );
}

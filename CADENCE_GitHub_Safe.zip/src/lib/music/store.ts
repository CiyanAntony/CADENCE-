import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PRESETS, slotsFromPreset } from "@/lib/music/presets";
import {
  createSlot,
  DEFAULT_SLOTS,
  uid,
  type Accidental,
  type QualityId,
  type Register,
  type ScaleId,
  type Slot,
} from "@/lib/music/theory";

export type Timbre = "guitar" | "keys";

export type Playhead = {
  playing: boolean;
  counting: boolean;
  countBeat: number;
  chordIndex: number;
  beat: number;
};

export type SavedSketch = {
  id: string;
  name: string;
  updatedAt: number;
  keyId: string;
  scaleId: ScaleId;
  slots: Slot[];
  tempo: number;
  swing: number;
  patternId: string;
  timbre: Timbre;
  register: Register;
};

type CadenceState = {
  sketchName: string;
  keyId: string;
  scaleId: ScaleId;
  slots: Slot[];
  selectedId: string;
  cueIndex: number;
  tempo: number;
  swing: number;
  patternId: string;
  timbre: Timbre;
  register: Register;
  volume: number;
  loop: boolean;
  metronome: boolean;
  countIn: boolean;
  isolate: boolean;
  library: SavedSketch[];
  activeSketchId: string | null;
  playhead: Playhead;
  setKey: (keyId: string) => void;
  setScale: (scaleId: ScaleId) => void;
  select: (id: string) => void;
  setCue: (index: number) => void;
  updateSlot: (id: string, patch: Partial<Slot>) => void;
  addChord: (degree: number, placement: "end" | "after") => void;
  remove: (id: string) => void;
  move: (id: string, direction: -1 | 1) => void;
  duplicate: (id: string) => void;
  setAllBeats: (beats: number) => void;
  applyPreset: (id: string) => void;
  setTempo: (tempo: number) => void;
  setSwing: (swing: number) => void;
  setPattern: (patternId: string) => void;
  setTimbre: (timbre: Timbre) => void;
  setRegister: (register: Register) => void;
  setVolume: (volume: number) => void;
  setLoop: (loop: boolean) => void;
  setMetronome: (on: boolean) => void;
  setCountIn: (on: boolean) => void;
  setIsolate: (on: boolean) => void;
  setSketchName: (name: string) => void;
  saveSketch: () => void;
  loadSketch: (id: string) => void;
  deleteSketch: (id: string) => void;
  newSketch: () => void;
  setPlayhead: (playhead: Playhead) => void;
};

const INITIAL_PLAYHEAD: Playhead = {
  playing: false,
  counting: false,
  countBeat: 0,
  chordIndex: 0,
  beat: 0,
};

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function snapshot(state: CadenceState, id: string): SavedSketch {
  return {
    id,
    name: state.sketchName.trim() || "Untitled",
    updatedAt: Date.now(),
    keyId: state.keyId,
    scaleId: state.scaleId,
    slots: state.slots,
    tempo: state.tempo,
    swing: state.swing,
    patternId: state.patternId,
    timbre: state.timbre,
    register: state.register,
  };
}

export const useCadence = create<CadenceState>()(
  persist(
    (set, get) => ({
      sketchName: "Axis loop",
      keyId: "C",
      scaleId: "major",
      slots: DEFAULT_SLOTS,
      selectedId: DEFAULT_SLOTS[0].id,
      cueIndex: 0,
      tempo: 96,
      swing: 0,
      patternId: "folk",
      timbre: "guitar",
      register: "mid",
      volume: 82,
      loop: true,
      metronome: false,
      countIn: false,
      isolate: false,
      library: [],
      activeSketchId: null,
      playhead: INITIAL_PLAYHEAD,

      setKey: (keyId) => set({ keyId }),
      setScale: (scaleId) => set({ scaleId }),
      select: (id) => set({ selectedId: id }),
      setCue: (index) => set({ cueIndex: clamp(index, 0, Math.max(0, get().slots.length - 1)) }),

      updateSlot: (id, patch) =>
        set((state) => ({
          slots: state.slots.map((slot) => (slot.id === id ? { ...slot, ...patch } : slot)),
        })),

      addChord: (degree, placement) => {
        const state = get();
        if (state.slots.length >= 32) return;
        const beats = state.slots[state.slots.length - 1]?.beats ?? 4;
        const slot = createSlot({ degree, beats });
        const selectedIndex = state.slots.findIndex((item) => item.id === state.selectedId);
        const insertAt = placement === "after" && selectedIndex >= 0 ? selectedIndex + 1 : state.slots.length;
        const slots = [...state.slots];
        slots.splice(insertAt, 0, slot);
        let cueIndex = state.cueIndex;
        if (!state.playhead.playing) cueIndex = insertAt;
        else if (cueIndex >= insertAt) cueIndex += 1;
        set({ slots, selectedId: slot.id, cueIndex });
      },

      remove: (id) => {
        const state = get();
        if (state.slots.length <= 1) return;
        const index = state.slots.findIndex((slot) => slot.id === id);
        if (index < 0) return;
        const slots = state.slots.filter((slot) => slot.id !== id);
        const selectedId = state.selectedId === id ? slots[Math.min(index, slots.length - 1)].id : state.selectedId;
        let cueIndex = state.cueIndex;
        if (index < cueIndex) cueIndex -= 1;
        if (index === state.cueIndex) cueIndex = Math.min(index, slots.length - 1);
        set({ slots, selectedId, cueIndex: clamp(cueIndex, 0, slots.length - 1) });
      },

      move: (id, direction) => {
        const state = get();
        const index = state.slots.findIndex((slot) => slot.id === id);
        const target = index + direction;
        if (index < 0 || target < 0 || target >= state.slots.length) return;
        const slots = [...state.slots];
        const [item] = slots.splice(index, 1);
        slots.splice(target, 0, item);
        let cueIndex = state.cueIndex;
        if (cueIndex === index) cueIndex = target;
        else if (cueIndex === target) cueIndex = index;
        set({ slots, cueIndex });
      },

      duplicate: (id) => {
        const state = get();
        if (state.slots.length >= 32) return;
        const index = state.slots.findIndex((slot) => slot.id === id);
        if (index < 0) return;
        const copy = { ...state.slots[index], id: uid() };
        const slots = [...state.slots];
        slots.splice(index + 1, 0, copy);
        let cueIndex = state.cueIndex;
        if (!state.playhead.playing) cueIndex = index + 1;
        else if (cueIndex > index) cueIndex += 1;
        set({ slots, selectedId: copy.id, cueIndex });
      },

      setAllBeats: (beats) =>
        set((state) => ({
          slots: state.slots.map((slot) => ({ ...slot, beats })),
        })),

      applyPreset: (id) => {
        const preset = PRESETS.find((item) => item.id === id);
        if (!preset) return;
        const slots = slotsFromPreset(preset);
        const name = get().sketchName;
        const keepName = name.trim() !== "" && name !== "Untitled" && name !== "Axis loop";
        set({
          scaleId: preset.scaleId,
          patternId: preset.patternId,
          tempo: preset.tempo,
          swing: preset.swing,
          slots,
          selectedId: slots[0].id,
          cueIndex: 0,
          isolate: false,
          sketchName: keepName ? name : preset.name,
          activeSketchId: null,
        });
      },

      setTempo: (tempo) => set({ tempo: Math.round(clamp(tempo, 40, 200)) }),
      setSwing: (swing) => set({ swing: Math.round(clamp(swing, 0, 100)) }),
      setPattern: (patternId) => set({ patternId }),
      setTimbre: (timbre) => set({ timbre }),
      setRegister: (register) => set({ register }),
      setVolume: (volume) => set({ volume: Math.round(clamp(volume, 0, 100)) }),
      setLoop: (loop) => set({ loop }),
      setMetronome: (metronome) => set({ metronome }),
      setCountIn: (countIn) => set({ countIn }),
      setIsolate: (isolate) => set({ isolate }),
      setSketchName: (sketchName) => set({ sketchName }),

      saveSketch: () => {
        const state = get();
        const id = state.activeSketchId ?? uid();
        const item = snapshot(state, id);
        const library = state.library.some((sketch) => sketch.id === id)
          ? state.library.map((sketch) => (sketch.id === id ? item : sketch))
          : [item, ...state.library].slice(0, 24);
        set({ library, activeSketchId: id, sketchName: item.name });
      },

      loadSketch: (id) => {
        const sketch = get().library.find((item) => item.id === id);
        if (!sketch || sketch.slots.length === 0) return;
        set({
          sketchName: sketch.name,
          keyId: sketch.keyId,
          scaleId: sketch.scaleId,
          slots: sketch.slots,
          selectedId: sketch.slots[0].id,
          cueIndex: 0,
          tempo: sketch.tempo,
          swing: sketch.swing,
          patternId: sketch.patternId,
          timbre: sketch.timbre,
          register: sketch.register,
          isolate: false,
          activeSketchId: sketch.id,
          playhead: INITIAL_PLAYHEAD,
        });
      },

      deleteSketch: (id) =>
        set((state) => ({
          library: state.library.filter((sketch) => sketch.id !== id),
          activeSketchId: state.activeSketchId === id ? null : state.activeSketchId,
        })),

      newSketch: () => {
        const slot = createSlot({ degree: 1, beats: 4 });
        set({
          sketchName: "Untitled",
          slots: [slot],
          selectedId: slot.id,
          cueIndex: 0,
          isolate: false,
          activeSketchId: null,
          scaleId: "major",
          patternId: "folk",
          swing: 0,
          playhead: INITIAL_PLAYHEAD,
        });
      },

      setPlayhead: (playhead) => {
        const current = get().playhead;
        if (
          current.playing === playhead.playing &&
          current.counting === playhead.counting &&
          current.countBeat === playhead.countBeat &&
          current.chordIndex === playhead.chordIndex &&
          current.beat === playhead.beat
        ) {
          return;
        }
        set({ playhead });
      },
    }),
    {
      name: "cadence-desk-v1",
      skipHydration: true,
      partialize: (state) => ({
        sketchName: state.sketchName,
        keyId: state.keyId,
        scaleId: state.scaleId,
        slots: state.slots,
        selectedId: state.selectedId,
        cueIndex: state.cueIndex,
        tempo: state.tempo,
        swing: state.swing,
        patternId: state.patternId,
        timbre: state.timbre,
        register: state.register,
        volume: state.volume,
        loop: state.loop,
        metronome: state.metronome,
        countIn: state.countIn,
        isolate: state.isolate,
        library: state.library,
        activeSketchId: state.activeSketchId,
      }),
    },
  ),
);

export function followQuality(slot: Slot, quality: QualityId): Partial<Slot> {
  return { quality, lockQuality: true };
}

export function clearLock(slot: Slot): Partial<Slot> {
  return { lockQuality: false, accidental: slot.accidental === 0 ? 0 : 0, quality: slot.quality };
}

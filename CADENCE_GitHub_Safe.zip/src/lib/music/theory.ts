export type QualityId =
  | "maj"
  | "min"
  | "dim"
  | "aug"
  | "sus2"
  | "sus4"
  | "maj7"
  | "7"
  | "min7"
  | "m7b5"
  | "dim7"
  | "6"
  | "min6"
  | "add9"
  | "9"
  | "maj9"
  | "min9";

export type ScaleId = "major" | "naturalMinor" | "dorian" | "mixolydian" | "harmonicMinor";

export type Accidental = -1 | 0 | 1;

export type Register = "low" | "mid" | "high";

export type Slot = {
  id: string;
  degree: number;
  accidental: Accidental;
  lockQuality: boolean;
  quality: QualityId;
  inversion: 0 | 1 | 2;
  beats: number;
};

export type ResolvedChord = {
  rootPc: number;
  quality: QualityId;
  symbol: string;
  roman: string;
  role: string;
  midis: number[];
};

const LETTERS = ["C", "D", "E", "F", "G", "A", "B"] as const;
const NATURAL_PC = [0, 2, 4, 5, 7, 9, 11];

export const KEYS: { id: string; pc: number; letter: number; label: string }[] = [
  { id: "C", pc: 0, letter: 0, label: "C" },
  { id: "C#", pc: 1, letter: 0, label: "C♯" },
  { id: "D", pc: 2, letter: 1, label: "D" },
  { id: "Eb", pc: 3, letter: 2, label: "E♭" },
  { id: "E", pc: 4, letter: 2, label: "E" },
  { id: "F", pc: 5, letter: 3, label: "F" },
  { id: "F#", pc: 6, letter: 3, label: "F♯" },
  { id: "G", pc: 7, letter: 4, label: "G" },
  { id: "Ab", pc: 8, letter: 5, label: "A♭" },
  { id: "A", pc: 9, letter: 5, label: "A" },
  { id: "Bb", pc: 10, letter: 6, label: "B♭" },
  { id: "B", pc: 11, letter: 6, label: "B" },
];

export const SCALES: { id: ScaleId; name: string; hint: string }[] = [
  { id: "major", name: "Major", hint: "Ionian" },
  { id: "naturalMinor", name: "Natural minor", hint: "Aeolian" },
  { id: "dorian", name: "Dorian", hint: "Minor with a major IV" },
  { id: "mixolydian", name: "Mixolydian", hint: "Major with a ♭VII" },
  { id: "harmonicMinor", name: "Harmonic minor", hint: "Minor with a major V" },
];

export const SCALE_INTERVALS: Record<ScaleId, number[]> = {
  major: [0, 2, 4, 5, 7, 9, 11],
  naturalMinor: [0, 2, 3, 5, 7, 8, 10],
  dorian: [0, 2, 3, 5, 7, 9, 10],
  mixolydian: [0, 2, 4, 5, 7, 9, 10],
  harmonicMinor: [0, 2, 3, 5, 7, 8, 11],
};

export const QUALITY_INTERVALS: Record<QualityId, number[]> = {
  maj: [0, 4, 7],
  min: [0, 3, 7],
  dim: [0, 3, 6],
  aug: [0, 4, 8],
  sus2: [0, 2, 7],
  sus4: [0, 5, 7],
  maj7: [0, 4, 7, 11],
  "7": [0, 4, 7, 10],
  min7: [0, 3, 7, 10],
  m7b5: [0, 3, 6, 10],
  dim7: [0, 3, 6, 9],
  "6": [0, 4, 7, 9],
  min6: [0, 3, 7, 9],
  add9: [0, 4, 7, 14],
  "9": [0, 4, 10, 14],
  maj9: [0, 4, 11, 14],
  min9: [0, 3, 10, 14],
};

export const QUALITY_SYMBOL: Record<QualityId, string> = {
  maj: "",
  min: "m",
  dim: "°",
  aug: "aug",
  sus2: "sus2",
  sus4: "sus4",
  maj7: "maj7",
  "7": "7",
  min7: "m7",
  m7b5: "m7♭5",
  dim7: "°7",
  "6": "6",
  min6: "m6",
  add9: "add9",
  "9": "9",
  maj9: "maj9",
  min9: "m9",
};

export const QUALITY_LABEL: Record<QualityId, string> = {
  maj: "maj",
  min: "min",
  dim: "dim",
  aug: "aug",
  sus2: "sus2",
  sus4: "sus4",
  maj7: "maj7",
  "7": "7",
  min7: "m7",
  m7b5: "m7♭5",
  dim7: "dim7",
  "6": "6",
  min6: "m6",
  add9: "add9",
  "9": "9",
  maj9: "maj9",
  min9: "m9",
};

export const QUALITY_GROUPS: { label: string; ids: QualityId[] }[] = [
  { label: "Triads", ids: ["maj", "min", "dim", "aug", "sus2", "sus4"] },
  { label: "Sevenths", ids: ["maj7", "7", "min7", "m7b5", "dim7"] },
  { label: "Color", ids: ["6", "min6", "add9", "maj9", "9", "min9"] },
];

const MINORISH = new Set<QualityId>(["min", "dim", "min7", "m7b5", "dim7", "min6", "min9"]);

const ROMAN_SUFFIX: Record<QualityId, string> = {
  maj: "",
  min: "",
  dim: "°",
  aug: "+",
  sus2: "sus2",
  sus4: "sus4",
  maj7: "maj7",
  "7": "7",
  min7: "7",
  m7b5: "ø7",
  dim7: "°7",
  "6": "6",
  min6: "6",
  add9: "add9",
  "9": "9",
  maj9: "maj9",
  min9: "9",
};

const UPPER = ["I", "II", "III", "IV", "V", "VI", "VII"];

/** Common next scale degrees for songwriting, 1-based. */
export const LEADS_TO: Record<number, number[]> = {
  1: [5, 4, 6, 2],
  2: [5, 4, 1],
  3: [6, 4, 1],
  4: [5, 1, 2],
  5: [1, 6, 4],
  6: [2, 4, 5, 1],
  7: [1, 5],
};

const REGISTER_FLOOR: Record<Register, number> = { low: 40, mid: 47, high: 55 };

export const DEFAULT_SLOTS: Slot[] = [
  { id: "c1", degree: 1, accidental: 0, lockQuality: false, quality: "maj", inversion: 0, beats: 4 },
  { id: "c2", degree: 5, accidental: 0, lockQuality: false, quality: "maj", inversion: 0, beats: 4 },
  { id: "c3", degree: 6, accidental: 0, lockQuality: false, quality: "min", inversion: 0, beats: 4 },
  { id: "c4", degree: 4, accidental: 0, lockQuality: false, quality: "maj", inversion: 0, beats: 4 },
];

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Math.random().toString(36).slice(2, 10)}`;
}

export function keyById(id: string) {
  return KEYS.find((key) => key.id === id) ?? KEYS[0];
}

export function scaleById(id: ScaleId) {
  return SCALES.find((scale) => scale.id === id) ?? SCALES[0];
}

export function createSlot(partial: Partial<Slot> & Pick<Slot, "degree">): Slot {
  return {
    id: partial.id ?? uid(),
    degree: partial.degree,
    accidental: partial.accidental ?? 0,
    lockQuality: partial.lockQuality ?? false,
    quality: partial.quality ?? "maj",
    inversion: partial.inversion ?? 0,
    beats: partial.beats ?? 4,
  };
}

export function spellNote(letterIndex: number, pc: number): string {
  const idx = ((letterIndex % 7) + 7) % 7;
  const letter = LETTERS[idx];
  const natural = NATURAL_PC[idx];
  let diff = pc - natural;
  diff = ((diff % 12) + 12) % 12;
  if (diff > 6) diff -= 12;
  if (diff === 0) return letter;
  if (diff > 0) return letter + "♯".repeat(diff);
  return letter + "♭".repeat(-diff);
}

export function scaleNotes(keyId: string, scaleId: ScaleId) {
  const key = keyById(keyId);
  return SCALE_INTERVALS[scaleId].map((interval, degree) => {
    const letter = (key.letter + degree) % 7;
    const pc = (key.pc + interval) % 12;
    return { pc, letter, name: spellNote(letter, pc) };
  });
}

export function diatonicQuality(scaleId: ScaleId, degreeIndex: number): QualityId {
  const scale = SCALE_INTERVALS[scaleId];
  const root = scale[degreeIndex];
  const third = scale[(degreeIndex + 2) % 7];
  const fifth = scale[(degreeIndex + 4) % 7];
  const d3 = (third - root + 12) % 12;
  const d5 = (fifth - root + 12) % 12;
  if (d3 === 4 && d5 === 7) return "maj";
  if (d3 === 3 && d5 === 7) return "min";
  if (d3 === 3 && d5 === 6) return "dim";
  if (d3 === 4 && d5 === 8) return "aug";
  return "maj";
}

export function romanNumeral(degree: number, accidental: Accidental, quality: QualityId): string {
  const base = UPPER[degree - 1] ?? "I";
  const body = MINORISH.has(quality) ? base.toLowerCase() : base;
  const prefix = accidental === -1 ? "♭" : accidental === 1 ? "♯" : "";
  return prefix + body + ROMAN_SUFFIX[quality];
}

export function harmonicRole(degree: number, accidental: Accidental, quality: QualityId): string {
  if (accidental === -1 && degree === 7) return "Subtonic";
  if (degree === 7) return quality === "maj" || quality === "7" ? "Subtonic" : "Leading";
  switch (degree) {
    case 1:
      return "Tonic";
    case 2:
      return "Predominant";
    case 3:
      return "Mediant";
    case 4:
      return "Subdominant";
    case 5:
      return "Dominant";
    case 6:
      return "Relative";
    default:
      return "Color";
  }
}

const LETTER_OFFSET = [0, 1, 1, 2, 2, 3, 4, 4, 4, 5, 6, 6];

function spellFromRoot(rootLetter: number, rootPc: number, interval: number): string {
  const semi = ((interval % 12) + 12) % 12;
  const letterOff = LETTER_OFFSET[semi] ?? 0;
  const letter = (rootLetter + letterOff) % 7;
  const pc = (rootPc + semi) % 12;
  return spellNote(letter, pc);
}

export function voiceChord(rootPc: number, intervals: number[], inversion: number, register: Register) {
  const floor = REGISTER_FLOOR[register];
  const rootMidi = floor + ((rootPc - (floor % 12) + 12) % 12);
  let notes = intervals.map((interval) => ({ interval, midi: rootMidi + interval }));
  notes.sort((a, b) => a.midi - b.midi);
  const inv = Math.min(Math.max(0, inversion), Math.max(0, notes.length - 1));
  for (let i = 0; i < inv; i++) {
    const moved = notes.shift();
    if (!moved) break;
    notes.push({ interval: moved.interval, midi: moved.midi + 12 });
  }
  if (notes[0] && notes[0].midi > floor + 10) {
    const shift = Math.floor((notes[0].midi - floor) / 12) * 12;
    notes = notes.map((note) => ({ ...note, midi: note.midi - shift }));
  }
  const top = notes[notes.length - 1];
  if (top && notes[0] && top.midi > 86 && notes[0].midi - 12 >= floor - 3) {
    notes = notes.map((note) => ({ ...note, midi: note.midi - 12 }));
  }
  return {
    midis: notes.map((note) => note.midi),
    bassInterval: notes[0]?.interval ?? 0,
  };
}

export function resolveSlot(slot: Slot, keyId: string, scaleId: ScaleId, register: Register): ResolvedChord {
  const spelled = scaleNotes(keyId, scaleId);
  const degreeIndex = Math.min(6, Math.max(0, slot.degree - 1));
  const scaleTone = spelled[degreeIndex];
  const rootPc = (scaleTone.pc + slot.accidental + 12) % 12;
  const quality = slot.lockQuality ? slot.quality : diatonicQuality(scaleId, degreeIndex);
  const intervals = QUALITY_INTERVALS[quality];
  const voiced = voiceChord(rootPc, intervals, slot.inversion, register);
  const rootName = spellNote(scaleTone.letter, rootPc);
  let symbol = rootName + QUALITY_SYMBOL[quality];
  if (slot.inversion > 0) {
    const bassName = spellFromRoot(scaleTone.letter, rootPc, voiced.bassInterval);
    if (bassName !== rootName) symbol += `/${bassName}`;
  }
  return {
    rootPc,
    quality,
    symbol,
    roman: romanNumeral(slot.degree, slot.accidental, quality),
    role: harmonicRole(slot.degree, slot.accidental, quality),
    midis: voiced.midis,
  };
}

export function formatProgression(slots: Slot[], keyId: string, scaleId: ScaleId) {
  const resolved = slots.map((slot) => resolveSlot(slot, keyId, scaleId, "mid"));
  return {
    symbols: resolved.map((chord) => chord.symbol).join(" – "),
    romans: resolved.map((chord) => chord.roman).join(" – "),
    resolved,
  };
}

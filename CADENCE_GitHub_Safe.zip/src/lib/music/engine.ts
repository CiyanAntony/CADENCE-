import { getPattern, type Pattern, type PatternEvent } from "@/lib/music/patterns";
import { useCadence } from "@/lib/music/store";
import { resolveSlot, type Slot } from "@/lib/music/theory";

export type Visual = {
  playing: boolean;
  counting: boolean;
  countBeat: number;
  chordIndex: number;
  beat: number;
  fraction: number;
  cellStep: number;
};

const IDLE: Visual = {
  playing: false,
  counting: false,
  countBeat: 0,
  chordIndex: 0,
  beat: 0,
  fraction: 0,
  cellStep: -1,
};

type Voice = { stop: () => void };
type Listener = (visual: Visual) => void;

function midiToFreq(midi: number) {
  return 440 * 2 ** ((midi - 69) / 12);
}

function positiveMod(value: number, size: number) {
  if (size <= 0) return 0;
  return ((value % size) + size) % size;
}

function sameVisual(a: Visual, b: Visual) {
  return (
    a.playing === b.playing &&
    a.counting === b.counting &&
    a.countBeat === b.countBeat &&
    a.chordIndex === b.chordIndex &&
    a.beat === b.beat &&
    a.cellStep === b.cellStep &&
    Math.abs(a.fraction - b.fraction) < 0.002
  );
}

class Player {
  private ctx: AudioContext | null = null;
  private input: GainNode | null = null;
  private master: GainNode | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private voices: Voice[] = [];
  private listeners = new Set<Listener>();
  private visual: Visual = IDLE;

  private running = false;
  private ending = false;
  private bpm = 96;
  private startAudioTime = 0;
  private startStep = 0;
  private resumeStep = 0;
  private scheduledUntil = 0;
  private countSixteenths = 0;
  private cueSixteenths = 0;
  private arpCursor = 0;
  private lastChord = -1;

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener(this.visual);
    return () => {
      this.listeners.delete(listener);
    };
  }

  toggle() {
    if (this.running) this.pause();
    else this.start();
  }

  start() {
    const ctx = this.ensure();
    if (!ctx) return;
    if (ctx.state === "suspended") void ctx.resume();
    const fresh = this.resumeStep < 0.04;
    const state = useCadence.getState();
    if (fresh) {
      this.resumeStep = 0;
      this.cueSixteenths = state.isolate ? 0 : cueOffset(state.slots, state.cueIndex);
      this.countSixteenths = state.countIn ? 16 : 0;
      this.arpCursor = 0;
      this.lastChord = -1;
    }
    this.ending = false;
    this.running = true;
    this.bpm = 0;
    this.reanchor(ctx.currentTime + 0.06, this.resumeStep);
    this.scheduledUntil = Math.ceil(this.resumeStep - 1e-4);
    this.tick();
  }

  pause() {
    if (!this.running || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.resumeStep = Math.max(0, this.stepAt(now));
    this.running = false;
    this.clearTimer();
    this.silence();
    const located = this.locate(this.resumeStep);
    this.emit({ ...located, playing: false, counting: false, cellStep: -1 });
  }

  stop() {
    this.running = false;
    this.ending = false;
    this.clearTimer();
    this.silence();
    this.resumeStep = 0;
    this.arpCursor = 0;
    this.lastChord = -1;
    const state = useCadence.getState();
    const chordIndex = state.isolate
      ? Math.max(0, state.slots.findIndex((slot) => slot.id === state.selectedId))
      : Math.min(state.cueIndex, Math.max(0, state.slots.length - 1));
    this.emit({ ...IDLE, chordIndex });
  }

  private ensure() {
    if (this.ctx) return this.ctx;
    if (typeof window === "undefined") return null;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return null;
    const ctx = new Ctx();
    const input = ctx.createGain();
    input.gain.value = 0.9;
    const highpass = ctx.createBiquadFilter();
    highpass.type = "highpass";
    highpass.frequency.value = 70;
    const body = ctx.createBiquadFilter();
    body.type = "lowpass";
    body.frequency.value = 4800;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -18;
    comp.knee.value = 18;
    comp.ratio.value = 3.4;
    comp.attack.value = 0.004;
    comp.release.value = 0.2;
    const delay = ctx.createDelay(1);
    delay.delayTime.value = 0.19;
    const feedback = ctx.createGain();
    feedback.gain.value = 0.22;
    const damp = ctx.createBiquadFilter();
    damp.type = "lowpass";
    damp.frequency.value = 2600;
    const wet = ctx.createGain();
    wet.gain.value = 0.2;
    const master = ctx.createGain();
    master.gain.value = 0.8;

    input.connect(highpass);
    highpass.connect(body);
    body.connect(comp);
    body.connect(delay);
    delay.connect(damp);
    damp.connect(feedback);
    feedback.connect(delay);
    damp.connect(wet);
    wet.connect(comp);
    comp.connect(master);
    master.connect(ctx.destination);

    this.ctx = ctx;
    this.input = input;
    this.master = master;
    return ctx;
  }

  private tick = () => {
    if (!this.running || !this.ctx) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const tempo = useCadence.getState().tempo;
    if (tempo !== this.bpm) {
      const step = this.bpm > 0 ? this.stepAt(now) : this.startStep;
      this.reanchor(now, step);
      this.scheduledUntil = Math.max(this.scheduledUntil, Math.ceil(step - 1e-4));
    }
    this.applyVolume(now);
    const horizon = now + 0.2;
    const sixteenth = 60 / this.bpm / 4;
    let step = Math.max(this.scheduledUntil, Math.ceil(this.stepAt(now) - 1e-4));
    let guard = 0;
    while (guard < 48) {
      const time = this.startAudioTime + (step - this.startStep) * sixteenth;
      if (time >= horizon) break;
      if (time >= now - 0.03) this.fire(step, time);
      step += 1;
      guard += 1;
    }
    this.scheduledUntil = step;
    this.emit(this.locate(this.stepAt(now)));
    this.timer = setTimeout(this.tick, 25);
  };

  private fire(step: number, time: number) {
    const state = useCadence.getState();
    if (step < this.countSixteenths) {
      if (step % 4 === 0) this.click(time, step === 0);
      return;
    }
    const music = step - this.countSixteenths + (state.isolate ? 0 : this.cueSixteenths);
    const slots = state.slots;
    if (slots.length === 0) return;
    const total = slots.reduce((sum, slot) => sum + slot.beats * 4, 0);
    if (!state.isolate && !state.loop && music >= total) {
      if (!this.ending) {
        this.ending = true;
        const wait = Math.max(0, (time - (this.ctx?.currentTime ?? time)) * 1000 + 40);
        setTimeout(() => {
          if (this.ending) this.stop();
        }, wait);
      }
      return;
    }
    const place = placement(music, slots, state.isolate, state.selectedId);
    if (!place) return;
    if (place.idx !== this.lastChord || place.local === 0) {
      this.arpCursor = 0;
      this.lastChord = place.idx;
    }
    if (state.metronome && place.local % 4 === 0) this.click(time, place.local === 0);
    const pattern = getPattern(state.patternId);
    const cell = pattern.cellBeats * 4;
    const inCell = place.local % cell;
    const swing = state.swing / 100;
    for (const event of pattern.events) {
      if (event.step !== inCell) continue;
      let when = time;
      if (swing > 0 && event.step % 4 === 2) {
        when += (60 / this.bpm / 4) * (2 / 3) * swing;
      }
      this.playEvent(when, event, slots[place.idx], pattern);
    }
  }

  private playEvent(when: number, event: PatternEvent, slot: Slot, pattern: Pattern) {
    const state = useCadence.getState();
    const chord = resolveSlot(slot, state.keyId, state.scaleId, state.register);
    const ordered = [...chord.midis].sort((a, b) => a - b);
    if (ordered.length === 0) return;
    const muted = Boolean(event.muted);
    if (event.gesture === "tone") {
      const index = ((event.tone ?? 0) % ordered.length + ordered.length) % ordered.length;
      this.note(when, ordered[index], event.velocity, event.decay, muted, 0.45);
      return;
    }
    if (event.gesture === "arp") {
      const index = arpIndex(ordered.length, this.arpCursor, pattern.arp ?? "up");
      this.arpCursor += 1;
      this.note(when, ordered[index], event.velocity, event.decay, muted, 0.62);
      return;
    }
    if (event.gesture === "upper") {
      const notes = ordered.slice(1);
      this.strum(when, notes.length > 0 ? notes : ordered, "down", event.velocity, event.decay, muted);
      return;
    }
    const direction = event.gesture === "up" ? "up" : event.gesture === "block" ? "block" : "down";
    this.strum(when, ordered, direction, event.velocity, event.decay, muted);
  }

  private strum(
    when: number,
    midis: number[],
    direction: "down" | "up" | "block",
    velocity: number,
    decay: number,
    muted: boolean,
  ) {
    const notes = direction === "up" ? [...midis].reverse() : midis;
    const gap = direction === "block" ? 0.0035 : muted ? 0.009 : 0.016;
    const brightness = direction === "up" ? 0.78 : direction === "block" ? 0.42 : 0.58;
    notes.forEach((midi, index) => {
      const detune = (index - (notes.length - 1) / 2) * 0.7;
      this.note(when + index * gap, midi, velocity * (1 - index * 0.035), decay, muted, brightness, detune);
    });
  }

  private note(
    when: number,
    midi: number,
    velocity: number,
    decay: number,
    muted: boolean,
    brightness: number,
    cents = 0,
  ) {
    const freq = midiToFreq(midi) * 2 ** (cents / 1200);
    if (!Number.isFinite(freq) || freq < 30 || freq > 4200) return;
    const human = (Math.random() - 0.5) * 0.008;
    const timbre = useCadence.getState().timbre;
    if (timbre === "keys") this.playKeys(freq, Math.max(0, when + human), decay, velocity, muted);
    else this.playGuitar(freq, Math.max(0, when + human), decay, velocity, brightness, muted);
  }

  private playGuitar(freq: number, when: number, decay: number, velocity: number, brightness: number, muted: boolean) {
    const ctx = this.ctx;
    const input = this.input;
    if (!ctx || !input) return;
    const sr = ctx.sampleRate;
    const tau = muted ? 0.055 : 0.2 + decay * 0.62;
    const seconds = muted ? 0.16 : Math.min(1.7, tau + 0.35);
    const length = Math.max(8, Math.floor(sr * seconds));
    const period = Math.max(2, Math.round(sr / freq - 0.5));
    const data = new Float32Array(length);
    const line = new Float32Array(period);
    for (let i = 0; i < period; i++) line[i] = Math.random() * 2 - 1;
    let lowpass = 0;
    const cut = muted ? 0.85 : 0.18 + brightness * 0.75;
    for (let i = 0; i < period; i++) {
      lowpass += cut * (line[i] - lowpass);
      line[i] = lowpass;
    }
    let peak = 0.0001;
    for (let i = 0; i < period; i++) peak = Math.max(peak, Math.abs(line[i]));
    for (let i = 0; i < period; i++) line[i] /= peak;
    const loss = Math.exp(-1 / (sr * tau));
    let prev = 0;
    for (let i = 0; i < length; i++) {
      const index = i % period;
      const current = line[index];
      const y = (current + prev) * 0.5;
      prev = y;
      line[index] = y * loss;
      data[i] = y;
    }
    const fadeIn = Math.min(length, Math.floor(sr * 0.0025));
    for (let i = 0; i < fadeIn; i++) data[i] *= i / fadeIn;
    const fadeOut = Math.min(length, Math.floor(sr * 0.02));
    for (let i = 0; i < fadeOut; i++) data[length - 1 - i] *= i / fadeOut;

    const buffer = ctx.createBuffer(1, length, sr);
    buffer.copyToChannel(data, 0);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(Math.max(0.0001, 0.2 * velocity), when);
    source.connect(gain);
    gain.connect(input);
    source.start(when);
    const voice = { stop() { try { source.stop(); } catch { /* already ended */ } } };
    this.voices.push(voice);
    source.onended = () => {
      this.voices = this.voices.filter((item) => item !== voice);
    };
  }

  private playKeys(freq: number, when: number, decay: number, velocity: number, muted: boolean) {
    const ctx = this.ctx;
    const input = this.input;
    if (!ctx || !input) return;
    const gain = ctx.createGain();
    const peak = (muted ? 0.07 : 0.15) * velocity;
    const dur = muted ? 0.12 : Math.min(1.8, 0.28 + decay * 0.7);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), when + 0.012);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak * 0.4), when + Math.min(0.18, dur * 0.4));
    gain.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    const oscs: OscillatorNode[] = [];
    const partials = [1, 2, 3, 4, 5.02];
    const amps = [1, 0.32, 0.16, 0.07, 0.035];
    for (let i = 0; i < partials.length; i++) {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq * partials[i], when);
      const partialGain = ctx.createGain();
      partialGain.gain.value = amps[i];
      osc.connect(partialGain);
      partialGain.connect(gain);
      osc.start(when);
      osc.stop(when + dur + 0.02);
      oscs.push(osc);
    }
    gain.connect(input);
    const voice = {
      stop() {
        for (const osc of oscs) {
          try { osc.stop(); } catch { /* already ended */ }
        }
      },
    };
    this.voices.push(voice);
    oscs[0].onended = () => {
      this.voices = this.voices.filter((item) => item !== voice);
    };
  }

  private click(when: number, accent: boolean) {
    const ctx = this.ctx;
    const master = this.master;
    if (!ctx || !master) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(accent ? 1600 : 1080, when);
    gain.gain.setValueAtTime(accent ? 0.07 : 0.035, when);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + 0.035);
    osc.connect(gain);
    gain.connect(master);
    osc.start(when);
    osc.stop(when + 0.04);
    const voice = { stop() { try { osc.stop(); } catch { /* already ended */ } } };
    this.voices.push(voice);
    osc.onended = () => {
      this.voices = this.voices.filter((item) => item !== voice);
    };
  }

  private locate(stepFloat: number): Visual {
    const state = useCadence.getState();
    const slots = state.slots;
    if (!this.running || slots.length === 0) {
      return { ...this.visual, playing: false };
    }
    if (stepFloat < this.countSixteenths) {
      const cue = Math.min(state.cueIndex, slots.length - 1);
      return {
        playing: true,
        counting: true,
        countBeat: Math.min(4, Math.floor(Math.max(0, stepFloat) / 4) + 1),
        chordIndex: Math.max(0, cue),
        beat: 0,
        fraction: 0,
        cellStep: -1,
      };
    }
    const music = stepFloat - this.countSixteenths + (state.isolate ? 0 : this.cueSixteenths);
    const total = slots.reduce((sum, slot) => sum + slot.beats * 4, 0);
    if (!state.isolate && !state.loop && music >= total) {
      return {
        playing: true,
        counting: false,
        countBeat: 0,
        chordIndex: slots.length - 1,
        beat: Math.max(0, slots[slots.length - 1].beats - 1),
        fraction: 1,
        cellStep: -1,
      };
    }
    const place = placement(music, slots, state.isolate, state.selectedId);
    if (!place) return { ...IDLE, playing: true };
    const pattern = getPattern(state.patternId);
    const cell = pattern.cellBeats * 4;
    return {
      playing: true,
      counting: false,
      countBeat: 0,
      chordIndex: place.idx,
      beat: Math.min(slots[place.idx].beats - 1, Math.floor(place.local / 4)),
      fraction: place.length > 0 ? place.local / place.length : 0,
      cellStep: Math.floor(place.local) % cell,
    };
  }

  private emit(next: Visual) {
    const discreteChanged =
      next.playing !== this.visual.playing ||
      next.counting !== this.visual.counting ||
      next.countBeat !== this.visual.countBeat ||
      next.chordIndex !== this.visual.chordIndex ||
      next.beat !== this.visual.beat;
    this.visual = next;
    if (discreteChanged) {
      useCadence.getState().setPlayhead({
        playing: next.playing,
        counting: next.counting,
        countBeat: next.countBeat,
        chordIndex: next.chordIndex,
        beat: next.beat,
      });
    }
    if (!sameVisual(next, next)) return;
    for (const listener of this.listeners) listener(next);
  }

  private applyVolume(now: number) {
    if (!this.master) return;
    const volume = useCadence.getState().volume / 100;
    if (volume <= 0.001) this.master.gain.setValueAtTime(0, now);
    else this.master.gain.setTargetAtTime(volume, now, 0.04);
  }

  private reanchor(audioTime: number, step: number) {
    this.startAudioTime = audioTime;
    this.startStep = step;
    this.bpm = useCadence.getState().tempo || 96;
  }

  private stepAt(time: number) {
    const sixteenth = 60 / this.bpm / 4;
    return this.startStep + (time - this.startAudioTime) / sixteenth;
  }

  private silence() {
    for (const voice of this.voices) voice.stop();
    this.voices = [];
  }

  private clearTimer() {
    if (this.timer != null) clearTimeout(this.timer);
    this.timer = null;
  }
}

function cueOffset(slots: Slot[], cueIndex: number) {
  const index = Math.min(Math.max(0, cueIndex), Math.max(0, slots.length - 1));
  let total = 0;
  for (let i = 0; i < index; i++) total += slots[i].beats * 4;
  return total;
}

function placement(music: number, slots: Slot[], isolate: boolean, selectedId: string | null) {
  if (slots.length === 0) return null;
  if (isolate) {
    let idx = slots.findIndex((slot) => slot.id === selectedId);
    if (idx < 0) idx = 0;
    const length = Math.max(1, slots[idx].beats * 4);
    const local = positiveMod(music, length);
    return { idx, local, length };
  }
  const total = slots.reduce((sum, slot) => sum + slot.beats * 4, 0);
  if (total <= 0) return null;
  const pos = positiveMod(music, total);
  let acc = 0;
  for (let i = 0; i < slots.length; i++) {
    const length = slots[i].beats * 4;
    if (pos < acc + length || i === slots.length - 1) {
      return { idx: i, local: pos - acc, length };
    }
    acc += length;
  }
  return null;
}

function arpIndex(count: number, cursor: number, direction: "up" | "down" | "updown") {
  if (count <= 1) return 0;
  if (direction === "down") return count - 1 - (cursor % count);
  if (direction === "updown") {
    const cycle = (count - 1) * 2;
    const point = cursor % cycle;
    return point < count ? point : cycle - point;
  }
  return cursor % count;
}

export const engine = new Player();

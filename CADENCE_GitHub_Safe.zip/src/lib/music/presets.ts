import type { Accidental, QualityId, ScaleId, Slot } from "@/lib/music/theory";

export type PresetSlot = {
  degree: number;
  accidental?: Accidental;
  lockQuality?: boolean;
  quality?: QualityId;
  inversion?: 0 | 1 | 2;
  beats?: number;
};

export type Preset = {
  id: string;
  name: string;
  tag: string;
  numerals: string;
  scaleId: ScaleId;
  patternId: string;
  tempo: number;
  swing: number;
  slots: PresetSlot[];
};

function chord(
  degree: number,
  quality?: QualityId,
  extra?: Partial<PresetSlot>,
): PresetSlot {
  return {
    degree,
    lockQuality: quality != null,
    quality: quality ?? "maj",
    beats: 4,
    ...extra,
  };
}

const bluesForm = [1, 1, 1, 1, 4, 4, 1, 1, 5, 4, 1, 5].map((degree) =>
  chord(degree, "7"),
);

export const PRESETS: Preset[] = [
  {
    id: "axis",
    name: "Axis",
    tag: "Pop",
    numerals: "I – V – vi – IV",
    scaleId: "major",
    patternId: "folk",
    tempo: 96,
    swing: 0,
    slots: [chord(1), chord(5), chord(6), chord(4)],
  },
  {
    id: "sensitive",
    name: "Sensitive",
    tag: "Ballad",
    numerals: "vi – IV – I – V",
    scaleId: "major",
    patternId: "ballad",
    tempo: 76,
    swing: 0,
    slots: [chord(6), chord(4), chord(1), chord(5)],
  },
  {
    id: "doowop",
    name: "Doo-wop",
    tag: "Classic",
    numerals: "I – vi – IV – V",
    scaleId: "major",
    patternId: "ballad",
    tempo: 86,
    swing: 0,
    slots: [chord(1), chord(6), chord(4), chord(5)],
  },
  {
    id: "canon",
    name: "Canon",
    tag: "Classic",
    numerals: "I – V – vi – iii – IV – I – IV – V",
    scaleId: "major",
    patternId: "arp",
    tempo: 80,
    swing: 0,
    slots: [1, 5, 6, 3, 4, 1, 4, 5].map((degree) => chord(degree)),
  },
  {
    id: "turnaround",
    name: "ii–V–I",
    tag: "Jazz",
    numerals: "ii7 – V7 – Imaj7 – vi7",
    scaleId: "major",
    patternId: "finger",
    tempo: 112,
    swing: 0,
    slots: [chord(2, "min7"), chord(5, "7"), chord(1, "maj7"), chord(6, "min7")],
  },
  {
    id: "blues",
    name: "Quick blues",
    tag: "Blues",
    numerals: "I7 – IV7 – I7 – V7",
    scaleId: "major",
    patternId: "eighths",
    tempo: 92,
    swing: 70,
    slots: [chord(1, "7"), chord(4, "7"), chord(1, "7"), chord(5, "7")],
  },
  {
    id: "twelve",
    name: "12-bar blues",
    tag: "Blues",
    numerals: "I7 ×4 – IV7 ×2 – I7 ×2 – V7 – IV7 – I7 – V7",
    scaleId: "major",
    patternId: "eighths",
    tempo: 96,
    swing: 72,
    slots: bluesForm,
  },
  {
    id: "poppunk",
    name: "Pop punk",
    tag: "Pop",
    numerals: "I – V – vi – IV",
    scaleId: "major",
    patternId: "eighths",
    tempo: 168,
    swing: 0,
    slots: [chord(1), chord(5), chord(6), chord(4)],
  },
  {
    id: "flatseven",
    name: "Flat seven",
    tag: "Rock",
    numerals: "I – VII – IV – I",
    scaleId: "mixolydian",
    patternId: "downs",
    tempo: 108,
    swing: 0,
    slots: [chord(1), chord(7), chord(4), chord(1)],
  },
  {
    id: "minorpop",
    name: "Minor pop",
    tag: "Minor",
    numerals: "i – VI – III – VII",
    scaleId: "naturalMinor",
    patternId: "folk",
    tempo: 94,
    swing: 0,
    slots: [chord(1), chord(6), chord(3), chord(7)],
  },
  {
    id: "andalusian",
    name: "Andalusian",
    tag: "Minor",
    numerals: "i – VII – VI – V",
    scaleId: "naturalMinor",
    patternId: "downs",
    tempo: 104,
    swing: 0,
    slots: [chord(1), chord(7), chord(6), chord(5, "maj")],
  },
  {
    id: "cadence",
    name: "Minor cadence",
    tag: "Minor",
    numerals: "i – iv – V – i",
    scaleId: "harmonicMinor",
    patternId: "ballad",
    tempo: 84,
    swing: 0,
    slots: [chord(1), chord(4), chord(5), chord(1)],
  },
  {
    id: "dorian",
    name: "Dorian vamp",
    tag: "Modal",
    numerals: "i – IV – VII – IV",
    scaleId: "dorian",
    patternId: "offbeat",
    tempo: 92,
    swing: 0,
    slots: [chord(1), chord(4), chord(7), chord(4)],
  },
  {
    id: "creep",
    name: "Creep",
    tag: "Color",
    numerals: "I – III – IV – iv",
    scaleId: "major",
    patternId: "ballad",
    tempo: 78,
    swing: 0,
    slots: [chord(1, "maj"), chord(3, "maj"), chord(4, "maj"), chord(4, "min")],
  },
];

export function slotsFromPreset(preset: Preset): Slot[] {
  return preset.slots.map((slot, index) => ({
    id: `${preset.id}-${index}-${Math.random().toString(36).slice(2, 7)}`,
    degree: slot.degree,
    accidental: slot.accidental ?? 0,
    lockQuality: slot.lockQuality ?? false,
    quality: slot.quality ?? "maj",
    inversion: slot.inversion ?? 0,
    beats: slot.beats ?? 4,
  }));
}

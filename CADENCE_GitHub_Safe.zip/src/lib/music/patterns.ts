export type Gesture = "down" | "up" | "block" | "upper" | "arp" | "tone";

export type PatternEvent = {
  step: number;
  gesture: Gesture;
  velocity: number;
  decay: number;
  tone?: number;
  muted?: boolean;
};

export type Pattern = {
  id: string;
  name: string;
  group: "Strum" | "Arpeggio";
  blurb: string;
  cellBeats: number;
  arp?: "up" | "down" | "updown";
  events: PatternEvent[];
};

const downQuarters = [0, 4, 8, 12].map((step, index) => ({
  step,
  gesture: "down" as const,
  velocity: index === 0 ? 0.95 : 0.82,
  decay: 0.72,
}));

const eighths: PatternEvent[] = Array.from({ length: 8 }, (_, index) => ({
  step: index * 2,
  gesture: index % 2 === 0 ? "down" : "up",
  velocity: index % 2 === 0 ? 0.88 : 0.62,
  decay: 0.42,
}));

const arpEighths: PatternEvent[] = Array.from({ length: 8 }, (_, index) => ({
  step: index * 2,
  gesture: "arp" as const,
  velocity: 0.78,
  decay: 0.9,
}));

const cascade: PatternEvent[] = Array.from({ length: 8 }, (_, index) => ({
  step: index,
  gesture: "arp" as const,
  velocity: 0.6,
  decay: 0.72,
}));

export const PATTERNS: Pattern[] = [
  {
    id: "blocks",
    name: "Blocks",
    group: "Strum",
    blurb: "The whole chord on beat 1, a softer echo on beat 3.",
    cellBeats: 4,
    events: [
      { step: 0, gesture: "block", velocity: 0.92, decay: 1.45 },
      { step: 8, gesture: "block", velocity: 0.48, decay: 1.05 },
    ],
  },
  {
    id: "downs",
    name: "Downstrokes",
    group: "Strum",
    blurb: "Even quarter-note downs. Plain and sturdy.",
    cellBeats: 4,
    events: downQuarters,
  },
  {
    id: "eighths",
    name: "Eighths",
    group: "Strum",
    blurb: "Steady down-up. Add swing and it shuffles.",
    cellBeats: 4,
    events: eighths,
  },
  {
    id: "folk",
    name: "Folk",
    group: "Strum",
    blurb: "Campfire pattern: down, down-up, up, down-up.",
    cellBeats: 4,
    events: [
      { step: 0, gesture: "down", velocity: 0.96, decay: 0.58 },
      { step: 4, gesture: "down", velocity: 0.82, decay: 0.4 },
      { step: 6, gesture: "up", velocity: 0.6, decay: 0.32 },
      { step: 10, gesture: "up", velocity: 0.58, decay: 0.32 },
      { step: 12, gesture: "down", velocity: 0.8, decay: 0.4 },
      { step: 14, gesture: "up", velocity: 0.58, decay: 0.32 },
    ],
  },
  {
    id: "ballad",
    name: "Ballad",
    group: "Strum",
    blurb: "Long downs with a lift across beat 3.",
    cellBeats: 4,
    events: [
      { step: 0, gesture: "down", velocity: 0.94, decay: 1.2 },
      { step: 8, gesture: "down", velocity: 0.78, decay: 0.7 },
      { step: 10, gesture: "up", velocity: 0.55, decay: 0.46 },
      { step: 12, gesture: "down", velocity: 0.7, decay: 0.85 },
    ],
  },
  {
    id: "offbeat",
    name: "Offbeats",
    group: "Strum",
    blurb: "Short chops on the ands. Reggae and ska.",
    cellBeats: 4,
    events: [2, 6, 10, 14].map((step) => ({
      step,
      gesture: "up" as const,
      velocity: 0.74,
      decay: 0.18,
      muted: true,
    })),
  },
  {
    id: "boom",
    name: "Boom-chick",
    group: "Strum",
    blurb: "Alternating bass, then a short chord. Country pocket.",
    cellBeats: 4,
    events: [
      { step: 0, gesture: "tone", tone: 0, velocity: 0.96, decay: 0.75 },
      { step: 2, gesture: "upper", velocity: 0.55, decay: 0.2, muted: true },
      { step: 4, gesture: "tone", tone: 2, velocity: 0.9, decay: 0.75 },
      { step: 6, gesture: "upper", velocity: 0.52, decay: 0.2, muted: true },
      { step: 8, gesture: "tone", tone: 0, velocity: 0.92, decay: 0.75 },
      { step: 10, gesture: "upper", velocity: 0.52, decay: 0.2, muted: true },
      { step: 12, gesture: "tone", tone: 2, velocity: 0.88, decay: 0.75 },
      { step: 14, gesture: "upper", velocity: 0.5, decay: 0.2, muted: true },
    ],
  },
  {
    id: "waltz",
    name: "Waltz",
    group: "Strum",
    blurb: "Bass, then two light chords. Best on 3-beat chords.",
    cellBeats: 3,
    events: [
      { step: 0, gesture: "tone", tone: 0, velocity: 0.95, decay: 0.95 },
      { step: 4, gesture: "upper", velocity: 0.64, decay: 0.48 },
      { step: 8, gesture: "upper", velocity: 0.58, decay: 0.48 },
    ],
  },
  {
    id: "arp",
    name: "Arpeggio",
    group: "Arpeggio",
    blurb: "Eighth notes climbing the voicing.",
    cellBeats: 4,
    arp: "up",
    events: arpEighths,
  },
  {
    id: "cascade",
    name: "Cascade",
    group: "Arpeggio",
    blurb: "Sixteenth notes that rise and fall.",
    cellBeats: 2,
    arp: "updown",
    events: cascade,
  },
  {
    id: "finger",
    name: "Fingerpick",
    group: "Arpeggio",
    blurb: "Travis picking: bass under alternating inner notes.",
    cellBeats: 4,
    events: [
      { step: 0, gesture: "tone", tone: 0, velocity: 0.92, decay: 0.9 },
      { step: 2, gesture: "tone", tone: 3, velocity: 0.62, decay: 0.72 },
      { step: 4, gesture: "tone", tone: 1, velocity: 0.7, decay: 0.72 },
      { step: 6, gesture: "tone", tone: 2, velocity: 0.6, decay: 0.68 },
      { step: 8, gesture: "tone", tone: 0, velocity: 0.88, decay: 0.9 },
      { step: 10, gesture: "tone", tone: 2, velocity: 0.62, decay: 0.68 },
      { step: 12, gesture: "tone", tone: 1, velocity: 0.68, decay: 0.72 },
      { step: 14, gesture: "tone", tone: 3, velocity: 0.58, decay: 0.68 },
    ],
  },
  {
    id: "broken",
    name: "Broken",
    group: "Arpeggio",
    blurb: "Low note, then the rest of the chord together.",
    cellBeats: 4,
    events: [
      { step: 0, gesture: "tone", tone: 0, velocity: 0.92, decay: 1.05 },
      { step: 2, gesture: "upper", velocity: 0.76, decay: 0.95 },
      { step: 8, gesture: "tone", tone: 0, velocity: 0.86, decay: 1.05 },
      { step: 10, gesture: "upper", velocity: 0.7, decay: 0.9 },
    ],
  },
];

export function getPattern(id: string): Pattern {
  return PATTERNS.find((pattern) => pattern.id === id) ?? PATTERNS[3];
}
